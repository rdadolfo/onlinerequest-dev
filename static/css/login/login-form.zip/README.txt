A Pen created at CodePen.io. You can find this one at http://codepen.io/JonasBadalic/pen/dPyGWw.

 A login form UI with some simple css transitions.